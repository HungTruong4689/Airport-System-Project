#pragma once

int main_1(); // main function for exercise 1
int main_2();
int main_3();
int main_4();
int main_5();